#define GIT_DESCRIPTION ""
#define GIT_HASH ""
#define GIT_TIME ""
