# Code instructions:

## DQN with CNN on Doom:

`th learning-torch7-cnn.lua` to train a neural network from scratch, and test it

`th learning-torch7-cnn.lua --skipLearning --load results/model.net` to only test a pre-trained neural network file